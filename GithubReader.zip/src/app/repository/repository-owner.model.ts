export class RepositoryOwner {
  constructor(
    public login: string
  ) {}
}
